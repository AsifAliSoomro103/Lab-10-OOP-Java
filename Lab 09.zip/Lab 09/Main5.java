abstract class Employee {
    String name;
    int id;
    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }
    abstract double calculateSalary();
}
interface TaxPayer {
    void payTax();
}
class FullTimeEmployee extends Employee implements TaxPayer {
    private double monthlySalary;

    public FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    @Override
    double calculateSalary() {
        return monthlySalary;
    }

    @Override
    public void payTax() {
        double tax = monthlySalary * 0.10; // 10% tax
        System.out.println("Full-time employee " + name + " paid tax: $" + tax);
    }
}
class PartTimeEmployee extends Employee implements TaxPayer {
    private int hoursWorked;
    private double hourlyRate;

    public PartTimeEmployee(String name, int id, int hoursWorked, double hourlyRate) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    @Override
    double calculateSalary() {
        return hoursWorked * hourlyRate;
    }

    @Override
    public void payTax() {
        double salary = calculateSalary();
        double tax = salary * 0.05; // 5% tax
        System.out.println("Part-time employee " + name + " paid tax: $" + tax);
    }
}
public class Main5 {
    public static void main(String[] args) {
        FullTimeEmployee emp1 = new FullTimeEmployee("Alice", 101, 5000);
        System.out.println(emp1.name + "'s Salary: $" + emp1.calculateSalary());
        emp1.payTax();

        System.out.println();
        PartTimeEmployee emp2 = new PartTimeEmployee("Bob", 102, 80, 20);
        System.out.println(emp2.name + "'s Salary: $" + emp2.calculateSalary());
        emp2.payTax();
    }
}
