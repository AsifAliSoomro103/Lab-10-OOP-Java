interface Vehicle {
    void start();
    void stop();
}
class Car implements Vehicle {
    @Override
    public void start() {
        System.out.println("Car is starting with a key...");
    }

    @Override
    public void stop() {
        System.out.println("Car is stopping with brake...");
    }
}
class Bike implements Vehicle {
    @Override
    public void start() {
        System.out.println("Bike is starting with a kick...");
    }

    @Override
    public void stop() {
        System.out.println("Bike is stopping with disc brake...");
    }
}
public class Main2 {
    public static void main(String[] args) {
        Vehicle car = new Car();
        Vehicle bike = new Bike();

        car.start();
        car.stop();
        bike.start();
        bike.stop();
    }
}
